// Selecting the element with class 'student-list' from the document
const studentList =  document.querySelector('.student-list');

// Getting an array of all children elements of the 'studentList' element
const studentItem = studentList.children; //return all li obj of as array

// Setting the number of items to display per page
const perPage = 10;

// Initialize the current page number
var page = 1;

// Initializing the page
const init = () => {
  // Getting the total number of users("users" in data.js)
  const total = users.length;
  // Looping through each user + renderUser(users[i]=user)
  for (i = 0; i < users.length; i++) {
    document.querySelector(".student-list").innerHTML += renderUser(users[i]);
  }
  // Displaying the total number of users
  document.querySelector(".total").innerText = `Total: ${total}`;
};

// Render user details
const renderUser = (user) => {
  return `
    <li class="student-item cf">
    <div class="student-details">
    <img class="avatar" src="${user.picture.thumbnail}">
    <h3>${user.name.first} ${user.name.last}</h3>
    <span class="email">${user.email}</span>
    </div>
    <div class="joined-details">
    <span class="date">Joined ${new Date(
      user.registered.date
    ).toLocaleDateString("en-US")}</span>
    </div>
    </li> `;
};

// Initializing the page
init();

// Function to show a specific page of students
const showPage = (list, page) => {
  for (let i = 0; i < list.length; i++) {
    // If index = within the range of the current page -> display the item
    // X within -> hide it
    if (i < page * 10 || i > page * 10 + 9) {
      list[i].style.display = "none";
    } else {
      list[i].style.display = "block";
    }
  }
};

// Showing the first page initially (studentItem=list, 0=page)
showPage(studentItem, 0);

// append pagination links
const appendPageLinks = (list) => {
  //1. total number of pages = number of items / items per page(10)
  const totalPages = Math.ceil(list.length / perPage);
  console.log(totalPages);

  //2. Set pagination container (=<div class="pagination">)
  const ItemList = document.querySelector("div.pagination");
  
  //3. Creating pagination buttons for each page
  for (let i = 1; i <= totalPages; i++) {
    // Adding new list item element
    var addbutton = document.createElement("li");
    
    // inner HTML of the list item = an anchor tag<a>(class= "active"(+css styles)) + a page number i
    addbutton.innerHTML = '<a class="active" >' + i + "</a>";
    
    // Appending the newly created list item (with the anchor tag inside) -> pagination container(=ItemList)
    ItemList.appendChild(addbutton);
  }
  
  // itembuttons = all the selected list item in "active" class (+css styles)
  var itembuttons = document.querySelectorAll(".active");

  // Logging the number of elements with the 'active' class
  console.log(itembuttons.length);

  //4. Looping through each element in 'active' class + Removing 'active' class(-css styles => default style)
  for (let i = 0; i < itembuttons.length; i++) {
    itembuttons[i].classList.remove("active");
  }

  //5. Adding event listeners -> each pagination button
  for (let i = 0; i < itembuttons.length; i++) {
    // + a 'click' event listener -> each pagination button
    itembuttons[i].addEventListener("click", () => {
      // button clicked -> Calls showPage() -> display the corresponding page
      showPage(studentItem, i);
      
      // Removing the 'active' class from all buttons (-css styles => default style)
      itembuttons[i].classList.remove("active");
    });
  }

};

// Appending pagination links (studentItem=list)
appendPageLinks(studentItem);
